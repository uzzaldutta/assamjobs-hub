"use client";

import Link from "next/link";
import { useState, useMemo, useRef, useEffect } from "react";
import { Clock, Sparkles } from "lucide-react";

interface Job {
  id: string;
  title: string;
  organization: string;
  type: string;
  category: string;
  vacancies?: string;
  district?: string;
  lastDate?: string;
  createdAt?: string;
}

interface RecentMarqueeProps {
  jobs: Job[];
  title: string;
}

const isExpiringSoon = (dateString?: string) => {
  if (!dateString) return false;
  const d = new Date(dateString);
  if (isNaN(d.getTime())) return false;
  const today = new Date();
  const diffDays = Math.ceil((d.getTime() - today.getTime()) / (1000 * 3600 * 24));
  return diffDays >= 0 && diffDays <= 3;
};

const isNewJob = (dateString?: string) => {
  if (!dateString) return false;
  const d = new Date(dateString);
  if (isNaN(d.getTime())) return false;
  const today = new Date();
  const diffDays = Math.ceil((today.getTime() - d.getTime()) / (1000 * 3600 * 24));
  return diffDays >= 0 && diffDays <= 2;
};

export default function RecentMarquee({ jobs, title }: RecentMarqueeProps) {
  const [activeTab, setActiveTab] = useState<"recent" | "closing">("recent");
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const pauseTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const displayJobs = useMemo(() => {
    if (activeTab === "recent") {
      return jobs.slice(0, 25);
    } else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const upcoming = jobs.filter(j => {
        if (!j.lastDate) return false;
        const d = new Date(j.lastDate);
        return !isNaN(d.getTime()) && d >= today;
      });

      upcoming.sort((a, b) => {
        return new Date(a.lastDate!).getTime() - new Date(b.lastDate!).getTime();
      });

      return upcoming.slice(0, 25);
    }
  }, [jobs, activeTab]);

  // Handle auto-scrolling
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || isPaused) return;

    let animationFrameId: number;
    const scrollStep = () => {
      if (el) {
        el.scrollLeft += 1; // Scroll speed
        // Reset to beginning seamlessly if we hit halfway point (since we duplicated the list)
        if (el.scrollLeft >= el.scrollWidth / 2) {
          el.scrollLeft -= el.scrollWidth / 2;
        }
      }
      animationFrameId = requestAnimationFrame(scrollStep);
    };

    animationFrameId = requestAnimationFrame(scrollStep);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPaused, activeTab]);

  const handleInteraction = () => {
    setIsPaused(true);
    if (pauseTimeoutRef.current) clearTimeout(pauseTimeoutRef.current);
    pauseTimeoutRef.current = setTimeout(() => {
      setIsPaused(false);
    }, 2000); // Resume 2 seconds after the user stops interacting
  };

  // Reset scroll when switching tabs
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = 0;
    }
  }, [activeTab]);

  if (!displayJobs || displayJobs.length === 0) return null;

  return (
    <div className="w-full mt-6 mb-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4 px-4 md:px-0">
        <div className="flex items-center gap-2">
          <span className="relative flex h-3 w-3">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${activeTab === 'closing' ? 'bg-red-400' : 'bg-emerald-400'}`}></span>
            <span className={`relative inline-flex rounded-full h-3 w-3 ${activeTab === 'closing' ? 'bg-red-500' : 'bg-emerald-500'}`}></span>
          </span>
          <h3 className="text-xl font-bold text-slate-800 dark:text-white">
            {activeTab === 'recent' ? 'Latest Updates' : 'Closing Soon'}
          </h3>
        </div>
        
        <div className="flex p-1 rounded-xl w-fit gap-2">
          <button 
            onClick={() => setActiveTab('recent')} 
            className={`px-4 py-1.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all duration-300 ${activeTab === 'recent' ? 'bg-emerald-600 shadow-md text-white scale-105 ring-2 ring-emerald-500/30' : 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100'} relative`}
          >
            {activeTab !== 'recent' && <span className="absolute top-0 right-0 w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span>}
            <Sparkles size={14} /> Recent
          </button>
          <button 
            onClick={() => setActiveTab('closing')} 
            className={`px-4 py-1.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all duration-300 ${activeTab === 'closing' ? 'bg-red-600 shadow-md text-white scale-105 ring-2 ring-red-500/30' : 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 hover:bg-red-100'} relative`}
          >
            {activeTab !== 'closing' && <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full animate-ping"></span>}
            <Clock size={14} /> Closing Soon
          </button>
        </div>
      </div>
      
      <div 
        ref={scrollRef}
        onMouseEnter={handleInteraction}
        onTouchStart={handleInteraction}
        onTouchMove={handleInteraction}
        onWheel={handleInteraction}
        className="flex overflow-x-auto hide-scrollbar relative w-full py-2 touch-pan-x"
        style={{ scrollBehavior: 'auto' }} // Ensure immediate tracking
      >
        {/* We render two identical lists side-by-side to create the seamless scroll effect */}
        {[1, 2].map((listIndex) => (
          <div key={`${activeTab}-${listIndex}`} className="flex gap-4 min-w-max pr-4" aria-hidden={listIndex === 2}>
            {displayJobs.map((job, jobIndex) => {
              const expiring = isExpiringSoon(job.lastDate);
              const isNew = !expiring && isNewJob(job.createdAt);
              
              let borderClass = 'border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700';
              if (expiring) {
                borderClass = 'border-red-400 dark:border-red-600 shadow-[0_0_15px_rgba(239,68,68,0.4)]';
              } else if (isNew) {
                borderClass = 'border-emerald-400 dark:border-emerald-600 shadow-[0_0_15px_rgba(16,185,129,0.3)]';
              }

              return (
                <Link key={`${listIndex}-${job.id}`} href={`/jobs/${job.id}`} className={`relative overflow-hidden w-[300px] shrink-0 bg-white dark:bg-slate-900 rounded-xl p-4 shadow-sm hover:shadow-md transition flex flex-col justify-between cursor-pointer border ${borderClass}`}>
                  
                  {/* Card Numbering Badge */}
                  <div className="absolute -top-3 -right-3 w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-full flex items-end justify-start pl-3 pb-2 text-xs font-black text-slate-400 opacity-60 pointer-events-none">
                    {jobIndex + 1}
                  </div>

                  {/* Flashing Background Layer */}
                  {expiring && <div className="absolute inset-0 bg-red-500/10 dark:bg-red-500/20 animate-pulse pointer-events-none"></div>}
                  {isNew && <div className="absolute inset-0 bg-emerald-500/10 dark:bg-emerald-500/20 animate-pulse pointer-events-none"></div>}

                  <div className="relative z-10 flex flex-col h-full justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-[10px] font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 px-2 py-1 rounded-md">
                          {job.type}
                        </span>
                        {expiring ? (
                          <span className="text-[10px] text-red-600 dark:text-red-500 font-bold flex items-center gap-1 animate-pulse">
                            <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span> Ends Soon
                          </span>
                        ) : isNew ? (
                          <span className="text-[10px] text-emerald-600 dark:text-emerald-500 font-bold flex items-center gap-1 animate-pulse">
                            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span> New Match
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-medium">Active</span>
                        )}
                      </div>
                      <h4 className="font-bold text-slate-800 dark:text-white text-sm line-clamp-2 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors leading-tight">
                        {job.title}
                      </h4>
                    </div>
                    <div className="mt-3 text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center justify-between">
                      <span className="truncate max-w-[150px]">{job.organization}</span>
                      {expiring && job.lastDate ? (
                        <span className="text-red-600 dark:text-red-400 font-bold text-[10px] truncate max-w-[100px]">End: {job.lastDate}</span>
                      ) : (
                        <span className="text-indigo-600 dark:text-indigo-400 font-bold">Read More &rarr;</span>
                      )}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
